import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'async-await-demo',
  templateUrl: './async-await-demo.component.html',
  styleUrls: ['./async-await-demo.component.scss']
})
export class AsyncAwaitDemoComponent implements OnInit {

  async printNumbers() {
    console.log("1");
    // console.log("2");
    var x = await this.getNumber();
    console.log(x);
    // var y = await getPromise
    // y.filter
    console.log("3");
  }

  getNumber(): Promise<number> {
    return new Promise(res => {
      setTimeout(() => {
        res(2);
      }, 3000);
    })
  }

  constructor() {
    console.log("before call printNumbers");
    this.printNumbers();
    console.log("after call printNumbers");
  }

  ngOnInit(): void {
  }

}
