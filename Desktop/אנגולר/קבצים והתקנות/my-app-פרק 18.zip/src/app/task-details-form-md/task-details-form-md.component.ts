import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { APP_USERS, User } from '../models/user.model';
import { Priority, Task } from '../task.model';

@Component({
  selector: 'task-details-form-md',
  templateUrl: './task-details-form-md.component.html',
  styleUrls: ['./task-details-form-md.component.scss']
})
export class TaskDetailsFormMDComponent implements OnInit {

  usersList: User[] = APP_USERS;

  priorityType = Priority;

  private _task?: Task;

  public get task(): Task | undefined {
    return this._task;
  }

  @Input()
  public set task(value: Task | undefined) {
    this._task = value;
    if (this.task != undefined) {
      this.taskForm = new FormGroup({
        "id": new FormControl(this.task.id),
        "name": new FormControl(this.task.name, [Validators.required, Validators.minLength(3)]),
        "description": new FormControl(this.task.description, Validators.required),
        "userId": new FormControl(this.task.userId, Validators.required),
        "priority": new FormControl(this.task.priority),
        "address": new FormGroup({
          "cityId": new FormControl(),
          "streetId": new FormControl()
        })
      });
    }
  }

  @Output()
  onSaveTask: EventEmitter<Task> = new EventEmitter();

  taskForm: FormGroup = new FormGroup({});

  saveNewTask() {
    // this.task.name = this.taskForm.controls["name"].value;
    // this.task.description = this.taskForm.controls["desc"].value;
    this.task = this.taskForm.value;
    this.onSaveTask.emit(this.task);
    //this.tasks.push(this.selectedTask);
  }

  @Output()
  onFirstFocus: EventEmitter<any> = new EventEmitter();
  firstFocusEmitted: boolean = false;

  inputFocus() {
    if (!this.firstFocusEmitted) {
      this.onFirstFocus.emit();
      this.firstFocusEmitted = true;
    }

  }

  constructor() { }

  ngOnInit(): void {
  }

}
