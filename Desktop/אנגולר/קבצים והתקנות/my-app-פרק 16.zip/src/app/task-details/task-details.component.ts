import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { Task } from '../task.model';

@Component({
  selector: 'task-details',
  templateUrl: './task-details.component.html',
  styleUrls: ['./task-details.component.scss']
})
export class TaskDetailsComponent implements OnInit {

  @Input()
  task?: Task;

  @Output()
  onSaveNewTask: EventEmitter<Task> = new EventEmitter();

  saveNewTask() {
    this.onSaveNewTask.emit(this.task);
    //this.tasks.push(this.selectedTask);
  }

  @Output()
  onFirstFocus: EventEmitter<any> = new EventEmitter();
  firstFocusEmitted: boolean = false;

  inputFocus() {
    if (!this.firstFocusEmitted) {
      this.onFirstFocus.emit();
      this.firstFocusEmitted = true;
    }

  }

  constructor() { }

  ngOnInit(): void {
    
  }

}
