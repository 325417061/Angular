import { Component, OnInit } from '@angular/core';
import { Priority, Task } from "../task.model"
import { TaskService } from '../task.service';

@Component({
  selector: 'task-list',
  templateUrl: './task-list.component.html'
})
export class TaskListComponent implements OnInit {

  priority = Priority;

  // tasks: Task[] = [
  //   { id: 1, name: "task1", description: "task 1 description", done: true },
  //   { id: 2, name: "task2", done: false, priority: Priority.High },
  //   { id: 3, name: "task3", done: true }];

  tasks: Task[] = this._taskService.getTasks();

  deleteTask(task: Task) {
    let indexToDelete = this.tasks.indexOf(task);
    this.tasks.splice(indexToDelete, 1);
  }

  selectedTask?: Task;// = this.tasks[0];

  showDetails(taskToShow: Task) {
    this.selectedTask = taskToShow;
  }

  showNewTaskDetails() {
    this.selectedTask = new Task("");

  }

  saveTaskToList(taskToSave: Task) {
    if (taskToSave.id == 0) {
      taskToSave.id = this.tasks.length + 1;
      this.tasks.push(taskToSave);
    }
    else {
      let taskToUpdate = this.tasks.filter(x => x.id == taskToSave.id)[0];
      let index = this.tasks.indexOf(taskToUpdate);
      this.tasks[index] = taskToSave;
    }
    this.selectedTask = new Task("");
  }

  addNewTaskToList(taskToAdd: Task) {
    this.tasks.push(taskToAdd);
    this.selectedTask = undefined;
  }
  
  addNewTaskToList2() {
    alert("save new task clicked");
  }

  showHelp() {
    // alert("You need Help?");
  }

  showAdv() {
    // alert("Show Advetise");
  }

  btnClick(e: any) {
  }

  search(str: string) {

  }

  constructor(private _taskService: TaskService) { }

  ngOnInit(): void {

  }

}
