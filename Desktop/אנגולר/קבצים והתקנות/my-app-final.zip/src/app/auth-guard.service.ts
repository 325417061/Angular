import { Injectable } from '@angular/core';
import { CanActivate } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class AuthGuardService implements CanActivate {

  someCondition: boolean = false;

  canActivate(): boolean {
    if (this.someCondition) {
      this.someCondition = false;
      return true;
    }
    alert("you cannot enter to this route");
    this.someCondition = true;
    return false;
  }

  constructor() { }
}
