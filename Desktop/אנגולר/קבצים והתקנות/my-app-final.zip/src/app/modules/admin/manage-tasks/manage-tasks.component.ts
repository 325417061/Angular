import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'manage-tasks',
  templateUrl: './manage-tasks.component.html',
  styleUrls: ['./manage-tasks.component.scss']
})
export class ManageTasksComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
