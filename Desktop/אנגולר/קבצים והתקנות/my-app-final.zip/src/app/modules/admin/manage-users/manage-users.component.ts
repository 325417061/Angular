import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'manage-users',
  templateUrl: './manage-users.component.html',
  styleUrls: ['./manage-users.component.scss']
})
export class ManageUsersComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
