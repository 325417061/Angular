import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'directives-demo',
  templateUrl: './directives-demo.component.html',
  styleUrls: ['./directives-demo.component.scss']
})
export class DirectivesDemoComponent implements OnInit {

  x: string = "a";

  tasks: string[] = ["task1", "task2", "task3", "task4", "task5"];

  isActive: boolean = true;

  id: number = 1;

  constructor() { }

  ngOnInit(): void {
  }

}
