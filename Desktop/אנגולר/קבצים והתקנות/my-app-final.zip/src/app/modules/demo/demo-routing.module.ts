import { NgModule } from "@angular/core";
import { RouterModule } from "@angular/router";
import { DirectivesDemoComponent } from "./directives-demo/directives-demo.component";


@NgModule({
    imports: [RouterModule.forChild([
        {path: "", pathMatch: "full", redirectTo: "directives"},
        {path: "directives", component: DirectivesDemoComponent}
    ])],
    exports: [RouterModule]
})
export class DemoRoutingModule {

}