import { Component, OnInit } from '@angular/core';
import { from, interval, Observable } from 'rxjs';
import { filter, map } from "rxjs/operators";

@Component({
  selector: 'observable-demo',
  templateUrl: './observable-demo.component.html'
})
export class ObservableDemoComponent implements OnInit {

  source: Observable<number> = new Observable((observer) => {
    observer.next(1);
    observer.next(2);
    observer.next(3);
    setTimeout(() => {
      observer.next(4);
    }, 3000);
    setTimeout(() => {
      observer.next(5);
    }, 1000);

    // observer.complete();
    observer.error("error from observable");
  });

  x: number = 0;

  timerValue: string = "";

  timer: Observable<Date> = new Observable(obs => {
    setInterval(() => {
      obs.next(new Date());
    }, 1000);
  });

  timerByOperator: Observable<Date> = interval(1000).pipe(map(x=> {return new Date()}));

  constructor() {
    this.source.pipe(map(x => { return x * 3; }), filter(x => { return x % 2 == 0; })).subscribe(
      (val) => {
        this.x = val;
        console.log("observable next is: " + val);
      },
      (err) => {
        this.x = 0;
        console.log(err);
      },
      () => {
        this.x = 0;
        console.log("observable is completed!")
      });

    this.timerByOperator.subscribe((val) => {
      this.timerValue = val.toLocaleTimeString();
    })
  }

  arr: any[] = [];

  studentsNames: Observable<string> = new Observable(obs=>{
    for(var i=0; i<this.arr.length; i++) {
      obs.next(this.arr[i].name);
    }
  });

  studentsNames2: Observable<string> = from(this.arr).pipe(map(x=>{ return x.name;}))

  ngOnInit(): void {
  }

}
