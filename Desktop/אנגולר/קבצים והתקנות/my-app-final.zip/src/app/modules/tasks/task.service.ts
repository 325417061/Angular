import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';
import { Priority, Task } from './task.model';

const TASKS = [
    { id: 1, name: "task1 from service", userId: 1, description: "task 1 description", done: true },
    { id: 2, name: "task2 from service", userId: 2, done: false, priority: Priority.High },
    { id: 3, name: "task3 from service", userId: 3, done: true }];


@Injectable()
export class TaskService {

    getTasks(): Task[] {
        return TASKS;
    };

    getTasksSlowly(): Promise<Task[]> {
        return new Promise((res, rej) => {
            setTimeout(() => {
                res(TASKS);
            }, 5000);
        })
    }

    // getTasksFromServer(): Promise<Task[]> {
    //     return new Promise(res=>{
    //         this._http.get<Task[]>("http://localhost:60509/api/Tasks").subscribe(data=>{
    //             res(data);
    //         });
    //     })
    // }

    getTasksFromServer(): Observable<Task[]> {
        // return this._http.get<Task[]>("/api/Tasks");
        return of(TASKS);
    }

    getTasksFromServerByDone(done: boolean): Observable<Task[]> {
        return this._http.get<Task[]>("/api/Tasks/" + done);
    }

    saveTasks(taskList: Task[]): Observable<boolean> {
        return this._http.post<boolean>("/api/Tasks", taskList);
    }

    getValue(): Promise<number> {
        return new Promise((reslove, reject) => {
            setTimeout(() => {
                // reslove(1);
                reject("no number found");
            }, 5000);


        });
    }

    callFunc() {
        console.log("before call getValue");
        var x: number;
        this.getValue().then((value) => {
            x = value;
            console.log("after get value from getValue Function. the value is:" + x);
        }).catch(err => {
            x = 0;
            console.log(err);
        });
        console.log("after call getValue");
    }

    constructor(private _http: HttpClient) {
        this.callFunc();
    }
}