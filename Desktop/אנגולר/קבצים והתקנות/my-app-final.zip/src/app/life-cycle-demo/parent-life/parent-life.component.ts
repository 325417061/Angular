import { AfterViewInit, Component, Input, OnChanges, OnDestroy, OnInit } from '@angular/core';

@Component({
  selector: 'parent-life',
  templateUrl: './parent-life.component.html'
})
export class ParentLifeComponent implements OnInit, OnChanges, AfterViewInit, OnDestroy {

  @Input() x: number = 5;

  constructor() {
    console.log("ParentLifeComponent ctor");
    console.log("x=" + this.x);
  }

  ngOnInit(): void {
    console.log("ParentLifeComponent component init");
    console.log("x=" + this.x);
  }

  ngOnChanges() {
    console.log("ParentLifeComponent cahnged");
  }

  ngAfterViewInit() {
    console.log("ParentLifeComponent after children init");
  }

  ngOnDestroy() {
    console.log("ParentLifeComponent destroy");
  }


}
