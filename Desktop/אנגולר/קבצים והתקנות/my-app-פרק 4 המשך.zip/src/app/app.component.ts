import { Component } from "@angular/core";

@Component({
    template: "<h1>{{title}}</h1><a href='#'>link</a>",
    selector: "my-app-root"
})
export class AppComponent {
    x: number = 5;

    title: string = "Hello My - App";

    calc() {
        return 0;
    }

    constructor() {
        //this.x = "sdfs";
    }

}