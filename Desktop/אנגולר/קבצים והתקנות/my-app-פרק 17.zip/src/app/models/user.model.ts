export class User {
    id: number = 0;
    name: string = "";
}

export const APP_USERS: User[] = [
    { id: 1, name: "moshe cohen" },
    { id: 2, name: "israel levi" },
    { id: 3, name: "avraham klein" }];