export class Task {
    id: number;
    name: string;
    description?: string;
    done?: boolean;
    priority?: Priority;
    userId?: number;

    constructor(name: string)  {
        this.id = 0;
        this.name = name;
    }
}

export enum Priority {
    High = 1,
    Medium = 2,
    Low = 3
}