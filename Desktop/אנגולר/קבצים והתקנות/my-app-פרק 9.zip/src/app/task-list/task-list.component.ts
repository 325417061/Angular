import { Component, OnInit } from '@angular/core';
import { Task } from "../task.model"

@Component({
  selector: 'task-list',
  templateUrl: './task-list.component.html'
})
export class TaskListComponent implements OnInit {

  tasks: Task[] = [
    { id: 1, name: "task1", description: "task 1 description" },
    { id: 2, name: "task2" },
    { id: 3, name: "task3" }];

  deleteTask(task: Task) {
    let indexToDelete = this.tasks.indexOf(task);
    this.tasks.splice(indexToDelete, 1);
  }

  selectedTask?: Task;// = this.tasks[0];

  showDetails(taskToShow: Task) {
    this.selectedTask = taskToShow;
  }

  showNewTaskDetails() {
    this.selectedTask = new Task("");

  }

  addNewTaskToList(taskToAdd: Task) {
    this.tasks.push(taskToAdd);
    this.selectedTask = undefined;
  }
  
  addNewTaskToList2() {
    alert("save new task clicked");
  }

  showHelp() {
    alert("You need Help?");
  }

  showAdv() {
    alert("Show Advetise");
  }

  btnClick(e: any) {
  }

  search(str: string) {

  }

  constructor() { }

  ngOnInit(): void {

  }

}
