export class Task {
    id: number;
    name: string;

    constructor(name: string)  {
        this.id = 0;
        this.name = name;
    }
}