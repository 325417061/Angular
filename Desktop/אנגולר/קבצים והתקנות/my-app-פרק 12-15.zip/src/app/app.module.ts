import { NgModule } from "@angular/core";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { BrowserModule } from "@angular/platform-browser";
import { AppComponent } from './app.component';
import { TaskDetailsFormMDComponent } from "./task-details-form-md/task-details-form-md.component";
import { TaskDetailsFormTDComponent } from "./task-details-form-td/task-details-form-td.component";
import { TaskDetailsComponent } from "./task-details/task-details.component";
import { TaskListComponent } from "./task-list/task-list.component";


@NgModule({
    declarations: [AppComponent, TaskListComponent, TaskDetailsComponent, TaskDetailsFormTDComponent, TaskDetailsFormMDComponent],
    imports: [BrowserModule, FormsModule, ReactiveFormsModule],
    bootstrap: [AppComponent]
})
export class AppModule {

}