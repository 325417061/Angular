import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { Task } from '../task.model';

@Component({
  selector: 'task-details-form-td',
  templateUrl: './task-details-form-td.component.html',
  styleUrls: ['./task-details-form-td.component.scss']
})
export class TaskDetailsFormTDComponent implements OnInit {

  @Input()
  task?: Task;

  @Output()
  onSaveNewTask: EventEmitter<Task> = new EventEmitter();

  saveNewTask() {
    this.onSaveNewTask.emit(this.task);
    //this.tasks.push(this.selectedTask);
  }

  @Output()
  onFirstFocus: EventEmitter<any> = new EventEmitter();
  firstFocusEmitted: boolean = false;

  inputFocus() {
    if (!this.firstFocusEmitted) {
      this.onFirstFocus.emit();
      this.firstFocusEmitted = true;
    }

  }

  constructor() { }

  ngOnInit(): void {
    
  }

}
